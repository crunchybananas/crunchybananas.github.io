# secret-scan

A reference Peel plugin that demonstrates **the tightest possible plugin profile**:
filesystem read on the user's CWD, plus a private cache directory. No network. No LLM. No
peelMCP callbacks. No env vars. Pure local pattern matching.

## What it does

One tool: `scan(path, includeGitignored?, minEntropy?, patterns?)`.

Walks a directory tree and flags likely committed secrets — API keys, tokens, private keys,
AWS access keys, JWT tokens, generic credential shapes — using:

1. **Regex patterns** for known secret prefixes (AWS, GitHub PAT, Slack, JWT, PEM, etc.)
2. **Shannon entropy** to catch high-entropy random-looking strings the regex set misses
3. **Confidence scoring** so callers can filter signal from noise

Returns:

```json
{
  "totalFiles": 47,
  "totalFindings": 2,
  "findings": [
    {
      "file": "/abs/path/to/file.env",
      "line": 12,
      "pattern": "aws-access-key",
      "preview": "AKIA****1234",
      "confidence": "high"
    }
  ]
}
```

Findings are sorted by confidence (high → medium → low) so the most actionable hits show up
first.

## Why no network and no LLM is a feature

Most secret scanners either send your code to a SaaS API or invoke a local LLM. Both fail
the same way: you can't run them on a private repo with confidence, and you can't run them
inside CI without a long policy review.

This plugin's manifest declares:

```json
"permissions": {
  "filesystem": { "read": ["$CWD/**"], "write": ["<plugin>/.cache/**"] },
  "network":   [],
  "peelMCP":   [],
  "env":       []
}
```

That's the tightest plugin profile Peel supports. The sandbox profile generated for it has
nothing to leak, nothing to phone home, nothing to ask the user about. It can be run on
the most sensitive repo a team owns and the only side effect is reading files.

It also makes it **fast**: 1000 files scan in under 5 seconds because there's no model
warmup, no network round-trip, and we stream files line-by-line without ever loading them
into memory.

## Redaction format

Findings always show **first 4 + last 4 chars + masked middle**:

```
AKIAIOSFODNN7EXAMPLE  ->  AKIA****MPLE
ghp_xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx  ->  ghp_****xxxx
```

Strings of 8 chars or fewer are fully masked. The full secret never crosses the plugin
boundary, so logs of `scan` results are safe to attach to bug reports.

## Installing

Copy this directory to `~/.peel/plugins/secret-scan/`, or use `plugins.install` once the
registry lands:

```bash
cp -r Docs/PLUGINS/examples/secret-scan ~/.peel/plugins/
```

Peel will pick it up on next plugin reload. Verify:

```bash
curl -s -X POST http://127.0.0.1:8765/rpc -H 'Content-Type: application/json' \
  -d '{"jsonrpc":"2.0","id":1,"method":"tools/call","params":{"name":"plugins.list","arguments":{}}}'
```

## Invoking

Plugin tools are namespaced `<pluginId>.<tool>`:

```bash
curl -s -X POST http://127.0.0.1:8765/rpc -H 'Content-Type: application/json' \
  -d '{"jsonrpc":"2.0","id":1,"method":"tools/call","params":{"name":"secret-scan.scan","arguments":{"path":"/Users/you/code/peel"}}}'
```

Tighten or loosen the entropy floor with `minEntropy` (default `4.5`). Add custom regex
rules per-call:

```json
{
  "path": "/abs/path",
  "minEntropy": 5.0,
  "patterns": ["MYAPP_TOKEN_[A-Z0-9]{32}"]
}
```

## What gets skipped

- `.git/`, `node_modules/`, `__pycache__/`, `build/`, `dist/`, `.build/`, common cache dirs
- Binary files (any null byte in the first 1024 bytes)
- Files larger than ~2MB (vendored or generated)
- Long lines (>4KB) that are almost always minified blobs
- By default, anything matched by a `.gitignore` at the scan root — pass
  `"includeGitignored": true` to scan `.env` and friends explicitly.

## Confidence levels

| Level | Meaning |
|-------|---------|
| `high` | Matched a known prefix (AWS access key, GitHub PAT, Slack token, PEM block, JWT). High confidence this is a real credential. |
| `medium` | Matched a `secret = "..."` / `api_key: "..."` shape with non-trivial entropy. Likely a real value, but could be a template. |
| `low` | High-entropy random-looking string (entropy >= `minEntropy`, length >= 20) that didn't match any named pattern. Most useful for catching custom token formats; expect noise. |

## Sandbox showcase

This plugin is the cleanest example of how restrictive a Peel plugin can be:

- **No `peelMCP`**: never calls back into Peel's tool surface
- **No `network`**: blocked by `PluginNetworkProxy` if it tried
- **No `env`**: doesn't read `OLLAMA_HOST`, `PEEL_MCP_URL`, or anything else
- **No Ollama**: no `requiredOllamaModels`, no `requiredMinMemoryGB`
- **Filesystem read** is scoped to the user's CWD via `$CWD/**` — Peel substitutes the
  user's working directory at sandbox-profile generation time, so the plugin can't sniff
  `~/.ssh/` or `/etc/` even if it tried.
- **Filesystem write** is scoped to its own `.cache/` directory under the plugin folder.
  Write attempts elsewhere are denied at the OS level.

## Gotchas

- Generic-credential matches (`secret = "..."`) are gated by entropy, so `password = "todo"`
  won't fire — but `password = "asd9q8347fhq3984hf9q834"` will. False-positive rate stays
  low without ML.
- The built-in `.gitignore` parser is intentionally minimal — it covers the common cases
  (`/`, `!`, `*`, `?`, directory-only patterns) but not the full Git spec. If you depend on
  exotic gitignore syntax, pass `includeGitignored: true` and rely on `SKIP_DIRS` plus your
  own filtering downstream.
- The plugin doesn't write anything by default. The `.cache/` write permission is reserved
  for a future "remember files we've already scanned by mtime" optimization.

## See also

- `Docs/PLUGINS/SPEC_v1.md` — full manifest and permission schema
- `Docs/PLUGINS/examples/commit-craft/` — example that uses peelMCP + Ollama
- `Docs/PLUGINS/examples/git-log-summary/` — explanation of the peelMCP callback pattern

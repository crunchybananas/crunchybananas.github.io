# commit-craft

Generic LLM commit message generators ignore your project's voice and produce flat, anonymous output. **commit-craft reads your repo's last 20 commits, learns the style — prefixes, mood, length, body conventions — then drafts a message for your staged diff that actually fits.**

## Why this matters

Every codebase has its own commit grammar. Some teams prefix with `[JIRA-123]`, some with `feat:` / `fix:`, some with emoji, some with nothing. Some write three-word subjects; some write three paragraphs. A message that ignores your repo's conventions reads as foreign — and gets rewritten by hand. This plugin closes that gap, so the AI-drafted message is the one you actually ship.

## What it does

One tool: `craft(repoPath, includeBody?, model?)`.

1. Calls Peel's `git.status` to confirm something is staged (clean error if not).
2. Calls `git.diff --staged` to get the changes you want described.
3. Calls `git.log --limit 20` to learn the project's voice.
4. Sends a two-part prompt to a local Ollama model: **exemplars first, diff second**, with explicit instructions to imitate (not invent) the house style.
5. Returns `{summary, body?, model, basedOnCommits}`.

## Installing

Copy this directory to `~/.peel/plugins/commit-craft/`:

```bash
cp -r Docs/PLUGINS/examples/commit-craft ~/.peel/plugins/
```

Make sure Ollama has at least one supported model:

```bash
ollama pull qwen2.5-coder:7b
```

## Invoking

```bash
curl -s -X POST http://127.0.0.1:8765/rpc -H 'Content-Type: application/json' \
  -d '{"jsonrpc":"2.0","id":1,"method":"tools/call","params":{"name":"commit-craft.craft","arguments":{"repoPath":"/Users/you/code/peel","includeBody":true}}}'
```

Run against a repo that prefixes its commits with terse summaries (the way Peel's own log reads) and you'll get something like:

```
DaemonActionDispatcher: dedupe alerts on (repo, kind, content-hash)

Two daemons firing the same Investigation Complete on the same repo within
the cooldown window were producing duplicate inbox rows. Hashing on the
rendered body (not the title) collapses them while still letting genuinely
different findings through.
```

Run the same plugin against a repo that uses `[TICKET-NNN] feat: …` and it'll produce that — same tool, different voice — because the exemplars do the steering.

The full response payload also includes machine-readable metadata:

```json
{
  "result": {
    "content": [{"type": "text", "text": "DaemonActionDispatcher: dedupe alerts ..."}],
    "_meta": {
      "summary": "DaemonActionDispatcher: dedupe alerts on (repo, kind, content-hash)",
      "body": "Two daemons firing the same Investigation Complete ...",
      "model": "qwen2.5-coder:7b",
      "basedOnCommits": 20
    }
  }
}
```

## Permissions

Tight by design — wider permissions on a daily-use tool draw skepticism:

| Surface | Grant | Why |
|---|---|---|
| `peelMCP` | `git.status`, `git.diff`, `git.log` | Read-only git introspection, nothing more. |
| `network` | `localhost:11434` only | Local Ollama. No outbound internet. |
| `filesystem` | `read: <plugin>/**`, `write: []` | Plugin reads its own files only; never touches the user's repo directly (the diff comes through the MCP callback). |
| `env` | `OLLAMA_HOST`, `PEEL_MCP_URL` | Standard Peel plugin env. |

A plugin that draws this minimal a permission set is auditable in 30 seconds.

## Design notes

- **Exemplars-first prompt.** The diff comes second, so the model anchors on the project's voice before it sees the code. Putting the diff first leads to generic commit prose because the model latches onto what the change *is* before it learns how to describe it.
- **Diff cap at 8000 chars.** A 7B model's context is ~8k tokens; we leave half for the exemplars + system prompt. Larger diffs are truncated with a note rather than blowing the window silently.
- **Refuse early on empty staging.** A clear `-32000` "nothing staged" beats a model hallucinating a message about an empty diff.
- **`includeBody` is opt-in.** Many repos never use bodies; defaulting to subject-only respects that and makes the common case faster.

## Gotchas

- Ollama must be running with one of `qwen2.5-coder:7b`, `qwen2.5:7b`, or `llama3.1:8b` pulled. The coder variant gives noticeably better diff comprehension.
- Repos with fewer than ~5 commits give the model thin style signal — it'll fall back to generic conventional-commits style. That's fine for a young repo.
- This plugin **drafts**, it doesn't commit. Wire it into your editor or a wrapper script if you want one-keystroke commits.

## See also

- `Docs/PLUGINS/examples/git-log-summary/` — same callback pattern, different goal (changelogs).
- `Docs/PLUGINS/SPEC_v1.md` — full manifest and permission schema.
